using CodeGenerator.Models;
using Scriban;
using Scriban.Runtime;
using System;
using System.IO;
using System.Text.Json;

/// <summary>
/// 根據資料庫欄位類型回傳對應的 HTML 輸入類型。
/// </summary>
/// <param name="type">資料庫欄位類型。</param>
/// <returns>HTML 輸入類型字串。</returns>
static string HtmlInputType(string type)
{
    return type?.ToLower() switch // 轉換為小寫以進行不區分大小寫比較
    {
        "string" => "text",
        "int" => "number",
        "integer" => "number",
        "bigint" => "number",
        "decimal" => "number",
        "float" => "number",
        "double" => "number",
        "date" => "date",
        "datetime" => "datetime-local",
        "bool" => "checkbox",
        "boolean" => "checkbox",
        _ => "text" // 預設為 text
    };
}

// --- 主程式開始 ---

// 設置 JsonSerializer 選項以忽略屬性名稱的大小寫
var options = new JsonSerializerOptions
{
    PropertyNameCaseInsensitive = true
};

// 定義設定檔路徑
var configPath = "config/user.json";

// 檢查設定檔是否存在
if (!File.Exists(configPath))
{
    Console.WriteLine($"錯誤: 找不到設定檔 '{configPath}'。");
    return;
}

// 讀取 JSON 配置並反序列化
var json = File.ReadAllText(configPath);
var table = JsonSerializer.Deserialize<TableConfig>(json, options);

// 檢查反序列化是否成功以及 table 是否為 null
if (table == null || string.IsNullOrEmpty(table.Name))
{
    Console.WriteLine($"錯誤: 無法從 '{configPath}' 讀取或解析有效的資料表設定。");
    return;
}

// 創建 Scriban ScriptObject 來存放數據模型
var model = new ScriptObject();
model.Add("table", table);
model.Add("columns", table.Columns); // 為了方便，也可以直接存取 table.Columns

// 創建 Scriban ScriptObject 來存放自訂函數
var functions = new ScriptObject();
functions.Import("html_input_type", new Func<string, string>(HtmlInputType));

// 創建並設定 TemplateContext
var ctx = new TemplateContext
{
    MemberFilter = member => true // 允許訪問所有公開成員
};

// 將自訂函數和數據模型推送到全域範圍
ctx.PushGlobal(functions);
ctx.PushGlobal(model);

// 定義要處理的模板和對應的輸出副檔名
var templates = new (string templateFile, string outputExt)[]
{
    ("form.sbn-html", "html"),
    ("controller.sbn-cs", "cs")
    // 您可以在這裡加入更多模板
};

// 確保輸出目錄存在
var outputDir = "output";
Directory.CreateDirectory(outputDir);

Console.WriteLine($"開始產生程式碼 (Table: {table.Name})...");

// 處理每個模板
foreach (var (templateFile, outputExt) in templates)
{
    var templatePath = Path.Combine("templates", templateFile);

    // 檢查模板檔案是否存在
    if (!File.Exists(templatePath))
    {
        Console.WriteLine($"警告: 找不到模板檔案 '{templatePath}'，已跳過。");
        continue;
    }

    try
    {
        var tplText = File.ReadAllText(templatePath);
        var tpl = Template.Parse(tplText);

        // 檢查模板解析是否有錯誤
        if (tpl.HasErrors)
        {
            Console.WriteLine($"錯誤: 解析模板 '{templateFile}' 時發生錯誤:");
            foreach (var error in tpl.Messages)
            {
                Console.WriteLine($"  - {error}");
            }
            continue; // 跳過這個有問題的模板
        }

        // 使用設定好的 Context 渲染模板
        var result = tpl.Render(ctx);

        // 建立輸出檔案路徑並寫入結果
        var outputPath = Path.Combine(outputDir, $"{table.Name}.{outputExt}");
        File.WriteAllText(outputPath, result);
        Console.WriteLine($"已成功產生: {outputPath}");
    }
    catch (Exception ex)
    {
        // 捕捉處理過程中的其他潛在錯誤
        Console.WriteLine($"❌ 錯誤: 處理模板 '{templateFile}' 時發生例外狀況: {ex.Message}");
    }
}

Console.WriteLine("程式碼產生完成！");
using System.Collections.Generic;

namespace CodeGenerator.Models;

public class TableConfig
{
    public string Name { get; set; }
    public List<ColumnConfig> Columns { get; set; }
}

public class ColumnConfig
{
    public string Name { get; set; }
    public string Type { get; set; }
    public bool Required { get; set; }
}
